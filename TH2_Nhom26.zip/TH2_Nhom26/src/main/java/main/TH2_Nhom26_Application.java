package main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TH2_Nhom26_Application {

	public static void main(String[] args) {
		SpringApplication.run(TH2_Nhom26_Application.class, args);
	}

}
